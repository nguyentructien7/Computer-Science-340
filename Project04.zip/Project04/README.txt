The program is written in java and run in netbeans.

-Run the program
-Then type in one of the following options:
-graphin.txt
-graphin1.txt

Then it will output into two separate files named Kuruskal and Prim.

