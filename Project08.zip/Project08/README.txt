The program is written in java and run in netbeans.

-Run the program

Then it will output the scores.
