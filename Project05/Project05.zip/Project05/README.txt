The program is written in java and run in netbeans.

-Run the program
-Then type in one of the following options:
-graphin.txt
-graphin1.txt
—etc

-Then select the valid input number within the range
-You can continue to type the selected digit if the program is not fail to build due to the negative edge and loop

-If you want to choose another graph, press run again.