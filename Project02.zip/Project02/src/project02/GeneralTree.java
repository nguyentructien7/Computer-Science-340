/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project02;

/**
 *
 * @author tnguyen
 */
public interface GeneralTree {
    public void insert(String word);
    public boolean contains(String word);
}
