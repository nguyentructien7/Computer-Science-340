The program is written in java and run in netbeans.

-Run the program
-If type “1” for the longest common subsequence
-type the first word
-type the second word

-If type “2” for optimal sequence
-type the first word
-type the second word
-type the match score
-type the gap score
-type the substitution score for similar characters (smaller than match)
-type the substitution score for dissimilar characters (Smaller than gap)
-All The scores are the user choice

Then it will output the scores and how it get it.

