The program is written in java and run in netbeans.

-Run the program
-Then type in one of the following options:
-graphin1.txt
-graphin2.txt
-acyclic.txt
Then the output will appeared on the output window.

Alex,

I tried to run it on home server, but I’m having difficulty to follow the instruction. I uploaded the project, but it is a little complicated for Java so it couldn’t compile. I still could not figure out how to do it yet. I hope you understand.
 The best way to run this project is to download netbeans and create a new project ”Project3” and copy/paste the code to that “Project3”. Then copy the all the “.txt” file to ”Project3” folder. I’m sorry for the trouble.